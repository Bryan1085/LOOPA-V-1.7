import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  Copy,
  Eye,
  Layers,
  MousePointerClick,
  Palette,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { EditSelectionMode } from '../core/mesh/operations';
import {
  clampMaterialFactor,
  getObjectMaterialSlotsSummary,
  hexToRgb,
  normalizeHexColor,
  rgbToHex,
} from '../core/project/hierarchy';
import {
  MaterialAsset,
  SceneObjectData,
  ViewportDisplayMode,
  WorkMode,
} from '../core/project/types';
import { NumericFieldInput } from './NumericFieldInput';

interface MaterialPanelProps {
  materials: MaterialAsset[];
  selectedObject: SceneObjectData | null;
  selectedObjectIds?: Set<string>;
  objects: SceneObjectData[];
  displayMode: ViewportDisplayMode;
  workMode?: WorkMode;
  editSelectionMode?: EditSelectionMode;
  selectedComponentIds?: Set<string>;
  getMaterialUsageSummary?: (materialId: string) => {
    objectCount: number;
    faceCount: number;
    usedByObjectIds: string[];
  };
  onActivateMaterialPreview: () => void;
  onCreateMaterial: (
    initial?: Partial<Omit<MaterialAsset, 'id'>>,
    assignToSelected?: boolean,
  ) => MaterialAsset;
  onRenameMaterial: (materialId: string, name: string) => void;
  onPushMaterialHistory: () => void;
  onUpdateMaterial: (
    materialId: string,
    patch: Partial<Omit<MaterialAsset, 'id'>>,
    recordHistory?: boolean,
  ) => void;
  onDuplicateMaterial: (
    materialId: string,
    assignToSelected?: boolean,
  ) => MaterialAsset | null;
  onDeleteMaterial: (materialId: string) => { ok: boolean; error?: string };
  onAssignMaterialToObjects: (objectIds: string[], materialId: string) => void;
  onAssignMaterialToFaces?: (
    objectId: string,
    faceIds: Set<string>,
    materialId: string,
  ) => void;
  onUnassignMaterialFromFaces?: (objectId: string, faceIds: Set<string>) => void;
  onSelectFacesByMaterial?: (objectId: string, materialId: string) => void;
}

export const MaterialPanel: React.FC<MaterialPanelProps> = ({
  materials,
  selectedObject,
  selectedObjectIds,
  objects,
  displayMode,
  workMode = 'object',
  editSelectionMode = 'vertex',
  selectedComponentIds,
  getMaterialUsageSummary,
  onActivateMaterialPreview,
  onCreateMaterial,
  onRenameMaterial,
  onPushMaterialHistory,
  onUpdateMaterial,
  onDuplicateMaterial,
  onDeleteMaterial,
  onAssignMaterialToObjects,
  onAssignMaterialToFaces,
  onUnassignMaterialFromFaces,
  onSelectFacesByMaterial,
}) => {
  const targetMeshIds = useMemo(() => {
    const meshIdSet = new Set(
      objects.filter((o) => o.objectType === 'mesh').map((o) => o.id),
    );
    const ids: string[] = [];
    if (selectedObjectIds && selectedObjectIds.size > 0) {
      for (const id of selectedObjectIds) {
        if (meshIdSet.has(id)) ids.push(id);
      }
    }
    if (ids.length === 0 && selectedObject && meshIdSet.has(selectedObject.id)) {
      ids.push(selectedObject.id);
    }
    return ids;
  }, [objects, selectedObject, selectedObjectIds]);

  const primaryMesh = useMemo(() => {
    if (selectedObject && selectedObject.objectType === 'mesh') {
      return selectedObject;
    }
    if (targetMeshIds.length > 0) {
      return objects.find((o) => o.id === targetMeshIds[0]) ?? null;
    }
    return null;
  }, [objects, selectedObject, targetMeshIds]);

  const [editingMaterialId, setEditingMaterialId] = useState<string>(
    () => primaryMesh?.materialId ?? materials[0]?.id ?? '',
  );

  useEffect(() => {
    if (
      primaryMesh?.materialId &&
      materials.some((m) => m.id === primaryMesh.materialId)
    ) {
      setEditingMaterialId(primaryMesh.materialId);
    }
  }, [primaryMesh?.id, primaryMesh?.materialId, materials]);

  useEffect(() => {
    if (!materials.some((m) => m.id === editingMaterialId)) {
      setEditingMaterialId(materials[0]?.id ?? '');
    }
  }, [editingMaterialId, materials]);

  const activeMaterial = useMemo(
    () => materials.find((m) => m.id === editingMaterialId) ?? materials[0] ?? null,
    [editingMaterialId, materials],
  );

  const [nameDraft, setNameDraft] = useState(activeMaterial?.name ?? '');
  const [hexDraft, setHexDraft] = useState(activeMaterial?.baseColor ?? '#9aa0a6');

  // New material creation drawer state
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newMatName, setNewMatName] = useState('');
  const [newMatColor, setNewMatColor] = useState('#5ecd6e');
  const [newMatOpacity, setNewMatOpacity] = useState(1);
  const [newMatMetallic, setNewMatMetallic] = useState(0.08);
  const [newMatRoughness, setNewMatRoughness] = useState(0.5);

  // Delete material warning prompt
  const [deleteWarning, setDeleteWarning] = useState<{
    material: MaterialAsset;
    objectCount: number;
    faceCount: number;
  } | null>(null);

  useEffect(() => {
    setNameDraft(activeMaterial?.name ?? '');
    setHexDraft(activeMaterial?.baseColor ?? '#9aa0a6');
  }, [activeMaterial?.id, activeMaterial?.name, activeMaterial?.baseColor]);

  const usageCounts = useMemo(() => {
    const counts = new Map<string, { objectCount: number; faceCount: number }>();
    for (const mat of materials) {
      if (getMaterialUsageSummary) {
        const s = getMaterialUsageSummary(mat.id);
        counts.set(mat.id, { objectCount: s.objectCount, faceCount: s.faceCount });
      } else {
        counts.set(mat.id, { objectCount: 0, faceCount: 0 });
      }
    }
    if (!getMaterialUsageSummary) {
      for (const obj of objects) {
        if (obj.objectType !== 'mesh') continue;
        const mid = obj.materialId ?? materials[0]?.id;
        if (!mid) continue;
        const prev = counts.get(mid) ?? { objectCount: 0, faceCount: 0 };
        counts.set(mid, { ...prev, objectCount: prev.objectCount + 1 });
      }
    }
    return counts;
  }, [getMaterialUsageSummary, materials, objects]);

  const objectSlotsSummary = useMemo(() => {
    if (!primaryMesh) return [];
    return getObjectMaterialSlotsSummary(primaryMesh, materials);
  }, [materials, primaryMesh]);

  const selectedFaceCount =
    workMode === 'edit' && editSelectionMode === 'face'
      ? selectedComponentIds?.size ?? 0
      : 0;
  const canAssignToSelectedFaces =
    Boolean(primaryMesh) &&
    !primaryMesh?.locked &&
    workMode === 'edit' &&
    editSelectionMode === 'face' &&
    selectedFaceCount > 0 &&
    Boolean(activeMaterial) &&
    Boolean(onAssignMaterialToFaces);
  const canUnassignSelectedFaces =
    Boolean(primaryMesh) &&
    !primaryMesh?.locked &&
    workMode === 'edit' &&
    editSelectionMode === 'face' &&
    selectedFaceCount > 0 &&
    Boolean(onUnassignMaterialFromFaces);

  const rgb = useMemo(
    () => hexToRgb(activeMaterial?.baseColor ?? '#9aa0a6'),
    [activeMaterial?.baseColor],
  );

  const commitName = () => {
    if (!activeMaterial) return;
    const trimmed = nameDraft.trim();
    if (!trimmed) {
      setNameDraft(activeMaterial.name);
      return;
    }
    if (trimmed !== activeMaterial.name) {
      onRenameMaterial(activeMaterial.id, trimmed);
    }
  };

  const commitHex = () => {
    if (!activeMaterial) return;
    const normalized = normalizeHexColor(hexDraft, activeMaterial.baseColor);
    setHexDraft(normalized);
    if (normalized !== activeMaterial.baseColor) {
      onUpdateMaterial(activeMaterial.id, { baseColor: normalized }, true);
    }
  };

  const updateRgbChannel = (channel: 'r' | 'g' | 'b', nextVal: number) => {
    if (!activeMaterial) return;
    const clamped = Math.max(0, Math.min(255, Math.round(nextVal)));
    const nextRgb = { ...rgb, [channel]: clamped };
    const nextHex = rgbToHex(nextRgb.r, nextRgb.g, nextRgb.b);
    onUpdateMaterial(activeMaterial.id, { baseColor: nextHex }, true);
  };

  const previewStyle = useMemo(() => {
    if (!activeMaterial) return undefined;
    const m = activeMaterial.metallic;
    const r = activeMaterial.roughness;
    const highlightOpacity = Math.max(0.08, (1 - r) * (0.42 + m * 0.4));
    const highlightSpread = Math.round(16 + r * 42);
    return {
      background: `radial-gradient(circle at 32% 28%, rgba(255,255,255,${highlightOpacity.toFixed(2)}) 0%, ${activeMaterial.baseColor} ${highlightSpread}%, #0c0e12 100%)`,
    };
  }, [activeMaterial]);

  return (
    <div className="flex-1 min-h-0 overflow-y-auto cad-scroll p-2.5 space-y-3">
      {/* Display Mode Prompt if not in Material Preview */}
      {displayMode !== 'material' && (
        <div className="rounded-lg bg-[#16261a] border border-[#5ecd6e]/40 p-2.5 space-y-2">
          <p className="text-[11px] text-[#cbd5e1] leading-relaxed">
            Activa <strong className="text-[#7def8e]">Material Preview</strong>{' '}
            para visualizar colores, metalizado y rugosidad en el visor 3D.
          </p>
          <button
            type="button"
            onClick={onActivateMaterialPreview}
            className="w-full h-8 px-2.5 rounded-md bg-[#49b459] hover:bg-[#5ecd6e] text-[#111215] text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Activar Material Preview</span>
          </button>
        </div>
      )}

      {/* Selected Object(s) Material Assignment */}
      <div className="rounded-lg bg-[#121418] border border-[#272b34] p-2.5 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-semibold text-[#d1d5db]">
            Asignación en selección
          </span>
          <span className="text-[10px] font-mono-tabular text-[#8e95a2] truncate max-w-[125px]">
            {targetMeshIds.length === 0
              ? 'Sin mallas'
              : targetMeshIds.length === 1
                ? primaryMesh?.name ?? '1 objeto'
                : `${targetMeshIds.length} objetos`}
          </span>
        </div>

        {targetMeshIds.length === 0 ? (
          <div className="text-[11px] text-[#7c8391]">
            Selecciona uno o varios objetos de malla para asignarles un material.
          </div>
        ) : (
          <select
            aria-label="Material asignado a la selección"
            value={primaryMesh?.materialId ?? activeMaterial?.id ?? ''}
            onChange={(e) => {
              const nextId = e.target.value;
              onAssignMaterialToObjects(targetMeshIds, nextId);
              setEditingMaterialId(nextId);
            }}
            className="w-full h-9 px-2.5 rounded-md bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs text-[#f3f4f6] outline-none"
          >
            {materials.map((mat) => (
              <option key={mat.id} value={mat.id}>
                {mat.name} ({mat.baseColor.toUpperCase()})
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Per-Object Material Slots & Face Assignment */}
      {primaryMesh && (
        <div
          data-testid="material-slots-section"
          className="rounded-lg bg-[#121418] border border-[#272b34] p-2.5 space-y-2.5"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-semibold text-[#d1d5db] flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#38bdf8]" />
              <span>Materiales del objeto ({objectSlotsSummary.length})</span>
            </span>
            {workMode === 'edit' && (
              <span className="text-[10px] font-mono-tabular text-[#5ecd6e]">
                {editSelectionMode === 'face'
                  ? `${selectedFaceCount} cara(s) sel.`
                  : 'Cambia a Caras'}
              </span>
            )}
          </div>

          {objectSlotsSummary.length > 0 && (
            <div className="space-y-1 max-h-32 overflow-y-auto cad-scroll pr-0.5">
              {objectSlotsSummary.map((slot) => {
                const matObj = materials.find((m) => m.id === slot.materialId);
                const isEditingSlot = activeMaterial?.id === slot.materialId;
                return (
                  <div
                    key={slot.materialId}
                    className={`rounded border px-2 py-1 flex items-center justify-between gap-1.5 ${
                      isEditingSlot
                        ? 'bg-[#202631] border-[#5ecd6e]/55'
                        : 'bg-[#171a21] border-[#262a34]'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setEditingMaterialId(slot.materialId)}
                      className="flex-1 min-w-0 flex items-center gap-1.5 text-left"
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-white/25 shrink-0"
                        style={{
                          backgroundColor: matObj?.baseColor ?? '#9aa0a6',
                          opacity: matObj?.opacity ?? 1,
                        }}
                      />
                      <span className="text-[11px] font-medium text-[#e4e6eb] truncate">
                        {matObj?.name ?? 'Material'}
                      </span>
                      {slot.isPrimary && (
                        <span className="px-1 py-0.2 rounded bg-[#16261a] text-[#6fe681] text-[9px] font-semibold shrink-0">
                          Base
                        </span>
                      )}
                    </button>
                    <span className="text-[10px] font-mono-tabular text-[#8e95a2] shrink-0">
                      {slot.faceCount}c
                    </span>
                    {onSelectFacesByMaterial && (
                      <button
                        type="button"
                        data-testid={`select-faces-material-${slot.materialId}`}
                        disabled={primaryMesh.locked}
                        onClick={() =>
                          onSelectFacesByMaterial(primaryMesh.id, slot.materialId)
                        }
                        title="Seleccionar todas las caras con este material"
                        className="h-6 px-1.5 rounded bg-[#212632] hover:bg-[#2c3342] text-[10px] font-semibold text-[#7dd3fc] flex items-center gap-1 disabled:opacity-40 shrink-0"
                      >
                        <MousePointerClick className="w-3 h-3" />
                        <span>Sel. caras</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Face Assignment & Unassignment Buttons */}
          <div className="space-y-1.5 pt-1 border-t border-[#232732]">
            <div className="grid grid-cols-1 gap-1.5">
              <button
                type="button"
                data-testid="assign-material-faces-btn"
                disabled={!canAssignToSelectedFaces}
                onClick={() => {
                  if (
                    primaryMesh &&
                    activeMaterial &&
                    selectedComponentIds &&
                    onAssignMaterialToFaces
                  ) {
                    onAssignMaterialToFaces(
                      primaryMesh.id,
                      selectedComponentIds,
                      activeMaterial.id,
                    );
                  }
                }}
                className="w-full min-h-[34px] px-2.5 py-1.5 rounded-md bg-[#49b459] hover:bg-[#5ecd6e] disabled:bg-[#20242c] disabled:text-[#6b7280] text-[#111215] text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Check className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">
                  Asignar «{activeMaterial?.name ?? 'Material'}» a caras seleccionadas
                </span>
              </button>

              <button
                type="button"
                data-testid="unassign-material-faces-btn"
                disabled={!canUnassignSelectedFaces}
                onClick={() => {
                  if (
                    primaryMesh &&
                    selectedComponentIds &&
                    onUnassignMaterialFromFaces
                  ) {
                    onUnassignMaterialFromFaces(
                      primaryMesh.id,
                      selectedComponentIds,
                    );
                  }
                }}
                className="w-full min-h-[32px] px-2.5 py-1 rounded-md bg-[#1d212a] hover:bg-[#272c38] border border-[#2f3544] disabled:opacity-40 text-[11px] font-medium text-[#cbd5e1] flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5 shrink-0 text-[#f59e0b]" />
                <span>Desasignar de caras seleccionadas</span>
              </button>
            </div>

            {!canAssignToSelectedFaces && (
              <p className="text-[10px] text-[#8e95a2] leading-snug">
                {workMode !== 'edit'
                  ? 'Entra en Modo Edición y selecciona caras para asignar materiales distintos por cara.'
                  : editSelectionMode !== 'face'
                    ? 'Cambia al modo de selección de Caras para asignar un material a caras específicas.'
                    : 'Selecciona una o más caras del objeto para asignar o desasignar el material activo.'}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Material Library List */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8e95a2] flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-[#5ecd6e]" />
            <span>Biblioteca ({materials.length})</span>
          </span>
          <button
            type="button"
            data-testid="open-create-material-btn"
            onClick={() => {
              setNewMatName(`Material ${materials.length + 1}`);
              setShowCreateForm((prev) => !prev);
            }}
            className="h-7 px-2 rounded bg-[#20242c] hover:bg-[#2a303b] border border-[#323846] text-[11px] font-semibold text-[#5ecd6e] flex items-center gap-1 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Crear nuevo material</span>
          </button>
        </div>

        {/* Inline Creation Form (+ Crear nuevo material) */}
        {showCreateForm && (
          <div
            data-testid="create-material-form"
            className="rounded-lg bg-[#161b22] border border-[#5ecd6e]/45 p-2.5 space-y-2.5"
          >
            <div className="text-[11px] font-semibold text-[#7def8e]">
              Nuevo material
            </div>
            <div className="space-y-1">
              <label className="block text-[10px] text-[#9ca3af]">Nombre</label>
              <input
                type="text"
                data-testid="create-material-name-input"
                value={newMatName}
                onChange={(e) => setNewMatName(e.target.value)}
                placeholder="Ej. Cristal Azul"
                className="w-full h-8 px-2 rounded bg-[#111317] border border-[#2f3440] focus:border-[#5ecd6e] text-xs text-[#f3f4f6] outline-none"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="color"
                aria-label="Color base del nuevo material"
                value={newMatColor}
                onChange={(e) => setNewMatColor(e.target.value)}
                className="w-9 h-8 p-0.5 rounded bg-[#111317] border border-[#2f3440] cursor-pointer shrink-0"
              />
              <input
                type="text"
                data-testid="create-material-color-input"
                value={newMatColor}
                onChange={(e) => setNewMatColor(e.target.value)}
                className="flex-1 min-w-0 h-8 px-2 rounded bg-[#111317] border border-[#2f3440] text-xs font-mono-tabular uppercase text-[#f3f4f6] outline-none"
              />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px] text-[#9ca3af]">
                <span>Opacidad</span>
                <span className="font-mono-tabular text-[#e4e6eb]">
                  {newMatOpacity.toFixed(2)}
                </span>
              </div>
              <input
                type="range"
                data-testid="create-material-opacity-input"
                min={0.05}
                max={1}
                step={0.05}
                value={newMatOpacity}
                onChange={(e) => setNewMatOpacity(parseFloat(e.target.value))}
                className="w-full h-2 accent-[#5ecd6e] cursor-pointer"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-0.5">
                <div className="flex justify-between text-[10px] text-[#9ca3af]">
                  <span>Metallic</span>
                  <span className="font-mono-tabular">
                    {newMatMetallic.toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={newMatMetallic}
                  onChange={(e) => setNewMatMetallic(parseFloat(e.target.value))}
                  className="w-full h-1.5 accent-[#5ecd6e] cursor-pointer"
                />
              </div>
              <div className="space-y-0.5">
                <div className="flex justify-between text-[10px] text-[#9ca3af]">
                  <span>Roughness</span>
                  <span className="font-mono-tabular">
                    {newMatRoughness.toFixed(2)}
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={newMatRoughness}
                  onChange={(e) => setNewMatRoughness(parseFloat(e.target.value))}
                  className="w-full h-1.5 accent-[#5ecd6e] cursor-pointer"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="h-8 rounded bg-[#222630] hover:bg-[#2c313e] text-[11px] font-medium text-[#cbd5e1]"
              >
                Cancelar
              </button>
              <button
                type="button"
                data-testid="confirm-create-material-btn"
                onClick={() => {
                  const cleanColor = normalizeHexColor(newMatColor, '#5ecd6e');
                  const created = onCreateMaterial(
                    {
                      name: newMatName.trim() || `Material ${materials.length + 1}`,
                      baseColor: cleanColor,
                      opacity: newMatOpacity,
                      metallic: newMatMetallic,
                      roughness: newMatRoughness,
                    },
                    false,
                  );
                  setEditingMaterialId(created.id);
                  setShowCreateForm(false);
                }}
                className="h-8 rounded bg-[#49b459] hover:bg-[#5ecd6e] text-[#111215] text-[11px] font-bold"
              >
                Crear material
              </button>
            </div>
          </div>
        )}

        <div className="space-y-1 max-h-40 overflow-y-auto cad-scroll pr-0.5">
          {materials.map((mat) => {
            const isSelectedForEdit = activeMaterial?.id === mat.id;
            const isAssignedToPrimary = primaryMesh?.materialId === mat.id;
            const usage = usageCounts.get(mat.id) ?? {
              objectCount: 0,
              faceCount: 0,
            };

            return (
              <div
                key={mat.id}
                className={`rounded-md border px-2 py-1.5 flex items-center justify-between gap-1.5 transition-colors ${
                  isSelectedForEdit
                    ? 'bg-[#252a35] border-[#5ecd6e]/65'
                    : 'bg-[#121418] border-[#262a33] hover:bg-[#1a1d24]'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setEditingMaterialId(mat.id)}
                  className="flex-1 min-w-0 flex items-center gap-2 text-left"
                >
                  <span
                    className="w-4 h-4 rounded-full border border-white/25 shrink-0"
                    style={{ backgroundColor: mat.baseColor }}
                  />
                  <span className="text-xs font-medium text-[#f3f4f6] truncate">
                    {mat.name}
                  </span>
                  {isAssignedToPrimary && (
                    <span
                      title="Asignado al objeto activo"
                      className="text-[#5ecd6e] shrink-0"
                    >
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </button>

                <div className="flex items-center gap-1 shrink-0">
                  <span
                    className="text-[10px] font-mono-tabular text-[#8e95a2] px-1"
                    title={`${usage.objectCount} objeto(s) · ${usage.faceCount} cara(s) extra`}
                  >
                    {usage.objectCount}
                    {usage.faceCount > 0 ? `+${usage.faceCount}c` : ''}
                  </span>
                  {targetMeshIds.length > 0 && !isAssignedToPrimary && (
                    <button
                      type="button"
                      onClick={() => {
                        onAssignMaterialToObjects(targetMeshIds, mat.id);
                        setEditingMaterialId(mat.id);
                      }}
                      title="Asignar a la selección"
                      className="h-6 px-1.5 rounded bg-[#1f242d] hover:bg-[#2c3340] text-[10px] font-semibold text-[#5ecd6e]"
                    >
                      Usar
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const copy = onDuplicateMaterial(mat.id, false);
                      if (copy) setEditingMaterialId(copy.id);
                    }}
                    title="Duplicar material"
                    aria-label={`Duplicar ${mat.name}`}
                    className="w-6 h-6 rounded hover:bg-[#313644] text-[#9ca3af] hover:text-white flex items-center justify-center"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    data-testid={`delete-material-${mat.id}`}
                    disabled={materials.length <= 1}
                    onClick={() => {
                      if (usage.objectCount > 0 || usage.faceCount > 0) {
                        setDeleteWarning({
                          material: mat,
                          objectCount: usage.objectCount,
                          faceCount: usage.faceCount,
                        });
                      } else {
                        onDeleteMaterial(mat.id);
                      }
                    }}
                    title={
                      materials.length <= 1
                        ? 'Debe permanecer al menos un material'
                        : 'Eliminar material'
                    }
                    aria-label={`Eliminar ${mat.name}`}
                    className="w-6 h-6 rounded hover:bg-[#3a2226] text-[#f87171] disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Delete In-Use Material Confirmation Modal */}
      {deleteWarning && (
        <div
          data-testid="delete-material-warning-modal"
          className="rounded-lg bg-[#26181c] border border-[#f87171]/60 p-3 space-y-2.5 shadow-xl"
        >
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-[#f87171] shrink-0 mt-0.5" />
            <div className="space-y-1 min-w-0">
              <div className="text-xs font-bold text-[#fecaca]">
                Material en uso: «{deleteWarning.material.name}»
              </div>
              <p className="text-[11px] text-[#fca5a5]/90 leading-snug">
                Este material está asignado actualmente a{' '}
                <strong>{deleteWarning.objectCount}</strong> objeto(s) y{' '}
                <strong>{deleteWarning.faceCount}</strong> cara(s) específica(s). Si lo
                eliminas, esas geometrías volverán al material predeterminado.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => setDeleteWarning(null)}
              className="h-8 rounded bg-[#222630] hover:bg-[#2c313e] text-[11px] font-medium text-[#e4e6eb]"
            >
              Cancelar
            </button>
            <button
              type="button"
              data-testid="confirm-delete-material-btn"
              onClick={() => {
                onDeleteMaterial(deleteWarning.material.id);
                setDeleteWarning(null);
              }}
              className="h-8 rounded bg-[#e05252] hover:bg-[#ef4444] text-white text-[11px] font-bold"
            >
              Eliminar de todos modos
            </button>
          </div>
        </div>
      )}

      {/* Active Material Properties Editor */}
      {activeMaterial && (
        <div className="rounded-lg bg-[#121418] border border-[#272b34] p-2.5 space-y-3">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-full border border-white/20 shadow-inner shrink-0"
              style={previewStyle}
              aria-hidden="true"
            />
            <div className="flex-1 min-w-0 space-y-1">
              <label className="block text-[10px] font-semibold uppercase tracking-wider text-[#8e95a2]">
                Nombre del material
              </label>
              <input
                type="text"
                value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                onBlur={commitName}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    commitName();
                    e.currentTarget.blur();
                  } else if (e.key === 'Escape') {
                    setNameDraft(activeMaterial.name);
                    e.currentTarget.blur();
                  }
                }}
                className="w-full h-8 px-2 rounded bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs font-medium text-[#f3f4f6] outline-none"
              />
            </div>
          </div>

          {/* Base Color + Hex */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-medium text-[#cbd5e1]">
              Base Color (Hex)
            </div>
            <div className="flex items-center gap-2">
              <input
                type="color"
                aria-label="Selector visual de Base Color"
                value={activeMaterial.baseColor}
                onPointerDown={onPushMaterialHistory}
                onChange={(e) => {
                  const next = normalizeHexColor(
                    e.target.value,
                    activeMaterial.baseColor,
                  );
                  setHexDraft(next);
                  onUpdateMaterial(activeMaterial.id, { baseColor: next }, false);
                }}
                className="w-10 h-9 p-0.5 rounded bg-[#181b22] border border-[#2f3440] cursor-pointer shrink-0"
              />
              <input
                type="text"
                aria-label="Código hexadecimal de color"
                value={hexDraft}
                onChange={(e) => setHexDraft(e.target.value)}
                onBlur={commitHex}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    commitHex();
                    e.currentTarget.blur();
                  } else if (e.key === 'Escape') {
                    setHexDraft(activeMaterial.baseColor);
                    e.currentTarget.blur();
                  }
                }}
                placeholder="#9AA0A6"
                className="flex-1 min-w-0 h-9 px-2.5 rounded bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs font-mono-tabular uppercase text-[#f3f4f6] outline-none"
              />
            </div>
          </div>

          {/* RGB 0 - 255 */}
          <div className="space-y-1">
            <div className="text-[11px] font-medium text-[#cbd5e1]">
              RGB (0–255)
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  { key: 'r', label: 'R', color: 'text-[#e05252]', val: rgb.r },
                  { key: 'g', label: 'G', color: 'text-[#52b852]', val: rgb.g },
                  { key: 'b', label: 'B', color: 'text-[#48bce8]', val: rgb.b },
                ] as const
              ).map((ch) => (
                <label
                  key={ch.key}
                  className="flex items-center bg-[#181b22] border border-[#2f3440] focus-within:border-[#5ecd6e] rounded px-1.5 h-9"
                >
                  <span className={`text-[11px] font-bold mr-1 ${ch.color}`}>
                    {ch.label}
                  </span>
                  <NumericFieldInput
                    ariaLabel={`Canal ${ch.label}`}
                    value={ch.val}
                    decimals={0}
                    onCommit={(val) => updateRgbChannel(ch.key, val)}
                    className="w-full bg-transparent text-xs font-mono-tabular text-[#f3f4f6] outline-none text-right"
                  />
                </label>
              ))}
            </div>
          </div>

          {/* Metallic */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#cbd5e1]">
                Metallic
              </span>
              <NumericFieldInput
                ariaLabel="Valor numérico de Metallic"
                value={activeMaterial.metallic}
                decimals={2}
                onCommit={(val) =>
                  onUpdateMaterial(
                    activeMaterial.id,
                    { metallic: clampMaterialFactor(val, activeMaterial.metallic) },
                    true,
                  )
                }
                className="w-16 h-7 px-1.5 rounded bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs font-mono-tabular text-[#f3f4f6] text-right outline-none"
              />
            </div>
            <input
              type="range"
              aria-label="Deslizador Metallic"
              min={0}
              max={1}
              step={0.01}
              value={activeMaterial.metallic}
              onPointerDown={onPushMaterialHistory}
              onChange={(e) =>
                onUpdateMaterial(
                  activeMaterial.id,
                  { metallic: parseFloat(e.target.value) },
                  false,
                )
              }
              className="w-full h-2 accent-[#5ecd6e] cursor-pointer"
            />
          </div>

          {/* Roughness */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#cbd5e1]">
                Roughness
              </span>
              <NumericFieldInput
                ariaLabel="Valor numérico de Roughness"
                value={activeMaterial.roughness}
                decimals={2}
                onCommit={(val) =>
                  onUpdateMaterial(
                    activeMaterial.id,
                    { roughness: clampMaterialFactor(val, activeMaterial.roughness) },
                    true,
                  )
                }
                className="w-16 h-7 px-1.5 rounded bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs font-mono-tabular text-[#f3f4f6] text-right outline-none"
              />
            </div>
            <input
              type="range"
              aria-label="Deslizador Roughness"
              min={0}
              max={1}
              step={0.01}
              value={activeMaterial.roughness}
              onPointerDown={onPushMaterialHistory}
              onChange={(e) =>
                onUpdateMaterial(
                  activeMaterial.id,
                  { roughness: parseFloat(e.target.value) },
                  false,
                )
              }
              className="w-full h-2 accent-[#5ecd6e] cursor-pointer"
            />
          </div>

          {/* Opacity */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-[#cbd5e1]">
                Opacidad
              </span>
              <NumericFieldInput
                ariaLabel="Valor numérico de Opacidad"
                value={activeMaterial.opacity ?? 1}
                decimals={2}
                onCommit={(val) =>
                  onUpdateMaterial(
                    activeMaterial.id,
                    {
                      opacity: Math.max(
                        0.02,
                        Math.min(1, clampMaterialFactor(val, activeMaterial.opacity ?? 1)),
                      ),
                    },
                    true,
                  )
                }
                className="w-16 h-7 px-1.5 rounded bg-[#181b22] border border-[#2f3440] focus:border-[#5ecd6e] text-xs font-mono-tabular text-[#f3f4f6] text-right outline-none"
              />
            </div>
            <input
              type="range"
              aria-label="Deslizador Opacidad"
              data-testid="active-material-opacity-slider"
              min={0.02}
              max={1}
              step={0.01}
              value={activeMaterial.opacity ?? 1}
              onPointerDown={onPushMaterialHistory}
              onChange={(e) =>
                onUpdateMaterial(
                  activeMaterial.id,
                  { opacity: parseFloat(e.target.value) },
                  false,
                )
              }
              className="w-full h-2 accent-[#5ecd6e] cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
